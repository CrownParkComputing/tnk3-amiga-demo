TNK III FIVE-MINUTE ROUTE DEMO

The shortened terrain and enemy-wave data are the complete demo.
Later campaign data is absent. There is no countdown to bypass.
Directions move; A/Ctrl cannon; B/Space machine gun; shoulders/Z/C turret.
Start pauses into Options. PLAYERS selects one or two alternating players.
MUSIC selects TNK III, Ikari Theme, Ikari Gate or OFF on the HD build.
Save & Quit retains high scores/options. The DD disk uses TNK III music.
Requires A1200/AGA,2MB Chip,8MB Fast and your own Kickstart3.1.
Stock CPU: multiplier4. Accelerated full colour: multiplier64,16x stock.
Original game/art/music SNK. Amiga conversion WHittyApps.
